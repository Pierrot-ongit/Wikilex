/* Source and licensing information for the line(s) below can be found at https://www.wikilex.xyz/sites/all/modules/admin_menu/admin_devel/admin_devel.js. */
(function(e){jQuery.extend({debug:function(){window.debug=window.debug||[];args=jQuery.makeArray(arguments);if(typeof this=='object'){var n=(args.length?args[0]:window.debug.length),e=this}
else{var n=(args.length>1?args.pop():window.debug.length),e=args[0]};window.debug[n]=e;if(typeof console!='undefined'){console.log(n,e)};return this}});jQuery.fn.debug=jQuery.debug})(jQuery);;
/* Source and licensing information for the above line(s) can be found at https://www.wikilex.xyz/sites/all/modules/admin_menu/admin_devel/admin_devel.js. */
/* Source and licensing information for the line(s) below can be found at https://www.wikilex.xyz/sites/all/modules/ctools/js/dropbutton.js. */
(function(o){Drupal.behaviors.CToolsDropbutton={attach:function(){o('.ctools-button').once('ctools-button').removeClass('ctools-no-js');o('.ctools-dropbutton').once('ctools-dropbutton',function(){var t=o(this),u=o('.ctools-content',t),e=o('li',u).not(':first'),l=o('.ctools-link',t),n=!1,i=!1,s=0,c=function(o){if(n||o){if(!o){n=!1;e.slideUp(100);t.removeClass('open')}
else{if(s){clearTimeout(s)};s=setTimeout(function(){if(!i){n=!1;e.slideUp(100);t.removeClass('open')}},500)}}
else{n=!0;e.animate({height:'show',opacity:'show'},100);t.addClass('open')}};e.hide();l.click(function(){c();return!1});t.hover(function(){i=!0},function(){i=!1;c(!0);return!1})})}}})(jQuery);;
/* Source and licensing information for the above line(s) can be found at https://www.wikilex.xyz/sites/all/modules/ctools/js/dropbutton.js. */

/**
 * Cookie plugin 1.0
 *
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */
jQuery.cookie=function(b,j,m){if(typeof j!="undefined"){m=m||{};if(j===null){j="";m.expires=-1}var e="";if(m.expires&&(typeof m.expires=="number"||m.expires.toUTCString)){var f;if(typeof m.expires=="number"){f=new Date();f.setTime(f.getTime()+(m.expires*24*60*60*1000))}else{f=m.expires}e="; expires="+f.toUTCString()}var l=m.path?"; path="+(m.path):"";var g=m.domain?"; domain="+(m.domain):"";var a=m.secure?"; secure":"";document.cookie=[b,"=",encodeURIComponent(j),e,l,g,a].join("")}else{var d=null;if(document.cookie&&document.cookie!=""){var k=document.cookie.split(";");for(var h=0;h<k.length;h++){var c=jQuery.trim(k[h]);if(c.substring(0,b.length+1)==(b+"=")){d=decodeURIComponent(c.substring(b.length+1));break}}}return d}};
;/**/
;/**/

/* Source and licensing information for the line(s) below can be found at https://www.wikilex.xyz/sites/all/modules/admin_menu/admin_devel/admin_devel.js. */
(function(e){jQuery.extend({debug:function(){window.debug=window.debug||[];args=jQuery.makeArray(arguments);if(typeof this=='object'){var n=(args.length?args[0]:window.debug.length),e=this}
else{var n=(args.length>1?args.pop():window.debug.length),e=args[0]};window.debug[n]=e;if(typeof console!='undefined'){console.log(n,e)};return this}});jQuery.fn.debug=jQuery.debug})(jQuery);;
/* Source and licensing information for the above line(s) can be found at https://www.wikilex.xyz/sites/all/modules/admin_menu/admin_devel/admin_devel.js. */
